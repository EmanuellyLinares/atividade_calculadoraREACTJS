import FormCalculadora from './components/FormCalculadora'
import './App.css'

function App() {
  return (
    <div className="pagina">
      <FormCalculadora />
    </div>
  )
}

export default App
