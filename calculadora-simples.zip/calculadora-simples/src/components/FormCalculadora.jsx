import { useState } from 'react'
import './FormCalculadora.css'

const SIMBOLOS = {
  soma: '+',
  subtracao: '−',
  multiplicacao: '×',
  divisao: '÷',
}

function calcular(num1, operacao, num2) {
  switch (operacao) {
    case 'soma':
      return num1 + num2
    case 'subtracao':
      return num1 - num2
    case 'multiplicacao':
      return num1 * num2
    case 'divisao':
      if (num2 === 0) {
        throw new Error('Não é possível dividir por zero')
      }
      return num1 / num2
    default:
      throw new Error('Selecione uma operação válida')
  }
}

function FormCalculadora() {
  const [primeiroNumero, setPrimeiroNumero] = useState('')
  const [segundoNumero, setSegundoNumero] = useState('')
  const [operacao, setOperacao] = useState('soma')
  const [resultado, setResultado] = useState(null)
  const [erro, setErro] = useState('')

  function handleCalcular(evento) {
    evento.preventDefault()

    const num1 = parseFloat(primeiroNumero)
    const num2 = parseFloat(segundoNumero)

    if (Number.isNaN(num1) || Number.isNaN(num2)) {
      setErro('Preencha os dois números para calcular')
      setResultado(null)
      return
    }

    try {
      const valor = calcular(num1, operacao, num2)
      setResultado(valor)
      setErro('')
    } catch (erroCalculo) {
      setErro(erroCalculo.message)
      setResultado(null)
    }
  }

  function handleLimpar() {
    setPrimeiroNumero('')
    setSegundoNumero('')
    setOperacao('soma')
    setResultado(null)
    setErro('')
  }

  const temResultado = resultado !== null && erro === ''

  return (
    <div className="calc-card">
      <header className="calc-card__cabecalho">
        <h1 className="calc-card__titulo">Calculadora simples</h1>
        <p className="calc-card__subtitulo">Some, subtraia, multiplique ou divida dois números</p>
      </header>

      <form className="calc-card__form" onSubmit={handleCalcular}>
        <div className="calc-equacao">
          <div className="calc-campo">
            <label className="calc-campo__rotulo" htmlFor="primeiroNumero">
              Primeiro número
            </label>
            <input
              id="primeiroNumero"
              className="calc-campo__input"
              type="number"
              step="any"
              inputMode="decimal"
              placeholder="0"
              value={primeiroNumero}
              onChange={(evento) => setPrimeiroNumero(evento.target.value)}
            />
          </div>

          <div className="calc-campo calc-campo--operacao">
            <label className="calc-campo__rotulo" htmlFor="operacao">
              Operação
            </label>
            <select
              id="operacao"
              className="calc-campo__select"
              value={operacao}
              onChange={(evento) => setOperacao(evento.target.value)}
            >
              <option value="soma">Soma (+)</option>
              <option value="subtracao">Subtração (−)</option>
              <option value="multiplicacao">Multiplicação (×)</option>
              <option value="divisao">Divisão (÷)</option>
            </select>
          </div>

          <div className="calc-campo">
            <label className="calc-campo__rotulo" htmlFor="segundoNumero">
              Segundo número
            </label>
            <input
              id="segundoNumero"
              className="calc-campo__input"
              type="number"
              step="any"
              inputMode="decimal"
              placeholder="0"
              value={segundoNumero}
              onChange={(evento) => setSegundoNumero(evento.target.value)}
            />
          </div>
        </div>

        <div className="calc-visor" aria-live="polite">
          {erro ? (
            <p className="calc-visor__erro">{erro}</p>
          ) : (
            <>
              <p className="calc-visor__equacao">
                {primeiroNumero || '0'} {SIMBOLOS[operacao]} {segundoNumero || '0'}
              </p>
              <p className="calc-visor__resultado">
                {temResultado ? resultado : '—'}
              </p>
            </>
          )}
        </div>

        <div className="calc-botoes">
          <button type="button" className="calc-botao calc-botao--limpar" onClick={handleLimpar}>
            Limpar
          </button>
          <button type="submit" className="calc-botao calc-botao--calcular">
            Calcular
          </button>
        </div>
      </form>
    </div>
  )
}

export default FormCalculadora
