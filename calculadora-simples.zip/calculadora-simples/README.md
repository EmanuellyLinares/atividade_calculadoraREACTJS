# 🧮 Calculadora Simples — React

Projeto desenvolvido como desafio prático de React, baseado na estrutura do exemplo da Calculadora de IMC. Permite somar, subtrair, multiplicar ou dividir dois números através de um formulário controlado.

## 🚀 Como executar

```bash
# instalar as dependências
npm install

# rodar em modo desenvolvimento
npm run dev
```

O terminal vai mostrar um endereço local (geralmente `http://localhost:5173`) para abrir no navegador.

## 📁 Estrutura do projeto

```
calculadora-simples/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── App.css
    ├── index.css
    └── components/
        ├── FormCalculadora.jsx
        └── FormCalculadora.css
```

## 🧩 Conceitos de React aplicados

- **Componentização**: a lógica e o layout da calculadora ficam isolados em `components/FormCalculadora.jsx`, separados do componente `App`, que só é responsável por montar a página. Isso segue o mesmo padrão do exemplo da Calculadora de IMC.

- **Hook `useState`**: cada campo do formulário (`primeiroNumero`, `segundoNumero`, `operacao`) e os estados de saída (`resultado`, `erro`) são controlados por `useState`. Isso caracteriza um **formulário controlado**: o valor exibido no input sempre vem do estado do React, e não do DOM.

- **Formulário controlado (`value` + `onChange`)**: os inputs e o `<select>` recebem `value={estado}` e atualizam o estado a cada `onChange`, garantindo que a interface reflita sempre o estado atual do componente.

- **Manipulação de eventos**: `handleCalcular` trata o evento de `submit` do formulário (com `evento.preventDefault()` para não recarregar a página) e `handleLimpar` trata o clique do botão "Limpar".

- **Renderização condicional**: o "visor" da calculadora mostra a equação e o resultado, ou uma mensagem de erro (ex: divisão por zero, campos vazios), usando operadores condicionais e o operador ternário dentro do JSX.

- **Separação de responsabilidades**: a função `calcular()` concentra a regra de negócio (as quatro operações matemáticas) fora do JSX, o que facilita testar e ler o componente.

- **Props implícitas via composição**: `App.jsx` importa e renderiza `<FormCalculadora />` sem passar props, mostrando a composição básica de componentes React.

- **CSS por componente (`FormCalculadora.css`)**: o estilo visual da calculadora vive junto do componente, com uma paleta e tipografia própria (inspirada em calculadoras de mesa, com um "visor" em tom de LCD), reforçando o conceito de estilos escopados por componente.

## 🎯 Funcionalidades

- Input para o primeiro e o segundo número
- `<select>` com as quatro operações: soma, subtração, multiplicação e divisão
- Botão **Calcular**, que executa a operação escolhida
- Botão **Limpar**, que reseta todos os campos e o resultado
- Validação de campos vazios e de divisão por zero, exibida no próprio visor
